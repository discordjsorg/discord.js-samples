module.exports = (client, info) => {
  client.logger.debug(info);
};
